import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import AppBar from "./AppNavigator";

const App = () => {
  return (
  	<>
      <AppBar />
  	</>
  );
};

export default App;
