import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import CalculatorScreen from './CalculatorScreen';
import LocationScreen from './LocationScreen';

const Drawer = createDrawerNavigator();

const AppNavigator = () => {
  return (
    <Drawer.Navigator initialRouteName="Calculator">
      <Drawer.Screen name="Calculator" component={CalculatorScreen} />
      <Drawer.Screen name="My Location" component={LocationScreen} />
    </Drawer.Navigator>
  );
};

export default AppNavigator;
